XBMC Project Mayhem III
For Xored Trainer Launcher 2.1

Coded & Designed by SupaDawg
Original Graphics by Chokemaniac
Alternate XBMC Logo by Chokemaniac

My Suggestions to Team Xored to make the skinning engine better:
1) Use something other than hex for X & Y co-ords
2) Un-anchor the music banner.
   it looks sloppy if you try to move it too the right of the screen
3) Fonts. 
   Font support is essential for a good looking skinning engine.

This skin was done prior to me trying the launcher. My first test 
came when I wanted to check out the launch screen. Great for a second 
version. Thank you for helping me rid my xbox of evox.

This was one of the first Xored skins and remains my personal favorite.

I suggest adding the trainer as a button in XBMC, for more help on
doing this please consult http://www.xboxmediacenter.de

Thanks to chokemaniac for authorizing the release.

Make the rest of your xbox look the same:
http://www.chokemaniac.net

Enjoy,
SupaDawg