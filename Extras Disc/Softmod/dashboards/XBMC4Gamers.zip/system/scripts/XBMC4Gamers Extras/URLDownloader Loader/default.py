from xbmc import executebuiltin
executebuiltin('ActivateWindow(1901)')