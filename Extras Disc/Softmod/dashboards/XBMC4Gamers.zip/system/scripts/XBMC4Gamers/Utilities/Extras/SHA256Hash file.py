import hashlib, os, xbmc, xbmcgui
dialog	= xbmcgui.Dialog()
dialogprogress = xbmcgui.DialogProgress()
percent = 0
Select_File = dialog.browse( 1,"Select file to hash",'files','' )
filesize = os.path.getsize( Select_File )
hash = hashlib.sha256()

if Select_File != "":
	for eachLine in open( Select_File, "rb", buffering=10485760):
		dialogprogress.update( (100*percent)/filesize,"Calculating sha256","This can take some time, please be patient." )
		hash.update(eachLine)
		percent = percent - (filesize/1)
		
	with open("E:\\sha256hash.txt","w") as output:
		output.write(hash.hexdigest())

	dialog.ok( "","Hash:",hash.hexdigest() )