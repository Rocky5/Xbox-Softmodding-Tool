Python directory structure

DLLs dir:
  Library directory used by python.
  python exensions (.pyd) are placed here

Spyce dir:
  Here is where the Spyce installation remains, this is only there for use with psp (python server pages)
  on the goahead webserver.

ssl dir:
  Contains cert.pem which holds root certificates for use with the python _ssl library.

python27.zlib
  This is a zip archive containing the core .py python libraries
