=================================
  UnleashX V0.39.0528 Build 584
          Network Patch
=================================

Here's a network patch for UnleashX. With this patch, it will only read and use the console's
current network settings, and not change them or use it's own settings. It's similar to XBMC's
"Default (Dashboard)" network settings mode. It will use the same settings as the MS Dashboard.
So when you have a custom DNS set (like Insignia), UnleashX won't set the DNS back to Automatic.
Note that with this network patch, you can't set any network settings in UnleashX itself (Network
toggling and FTP settings still work). If you need to change them, you can use the MS Dashboard
or another dashboard/app that's more friendly about network settings.

It also includes an FTP patch by Rocky5 to allow all FTP clients to work with UnleashX.

I and a few others got the network settings patch from someone awhile ago and it's worked great.
I thought I'd share it as many people have trouble with UnleashX always overwriting their network
settings unless they set them to Static. Now you can use the dashboard and not have to worry about
it overwriting them.

All the dashboard files have been included, otherwise if you already have UnleashX installed,
just copy the xbe and replace the original.

Thanks and greets:
Rocky5, James, TrustedShip, THPS2X
And a thank you to an anonymous individual for the network settings patch