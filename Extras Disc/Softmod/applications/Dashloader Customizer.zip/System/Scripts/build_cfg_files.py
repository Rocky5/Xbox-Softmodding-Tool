import os,xbmc,xbmcgui
A_Button = xbmc.getInfoLabel('Skin.String(A_Button)')
B_Button = xbmc.getInfoLabel('Skin.String(B_Button)')
X_Button = xbmc.getInfoLabel('Skin.String(X_Button)')
Y_Button = xbmc.getInfoLabel('Skin.String(Y_Button)')
Black_Button = xbmc.getInfoLabel('Skin.String(Black_Button)')
White_Button = xbmc.getInfoLabel('Skin.String(White_Button)')
Start_Button = xbmc.getInfoLabel('Skin.String(Start_Button)')
Back_Button = xbmc.getInfoLabel('Skin.String(Back_Button)')
Override_Dash = xbmc.getInfoLabel('Skin.String(Override_Dash)')
Recovery_Dash = xbmc.getInfoLabel('Skin.String(Recovery_Dash)')
if os.path.isdir('C:/Dashloader') and os.path.isfile('C:/Dashloader/Dashloader.log'):
	Save_Path = "C:/Dashloader/"
else:
	Save_Path = "E:/UDATA/21585554/000000000000/nkpatcher settings/dashloader/"
if xbmcgui.Dialog().yesno("EXIT","Would you like to exit and save changes?","","",'No','Yes'):
	try:
		if not os.path.isdir(Save_Path): os.makedirs(Save_Path)
		with open(Save_Path+"A_Button_Dash.cfg", 'w') as abutton:
			abutton.write(A_Button)
		with open(Save_Path+"B_Button_Dash.cfg", 'w') as bbutton:
			bbutton.write(B_Button)
		with open(Save_Path+"X_Button_Dash.cfg", 'w') as xbutton:
			xbutton.write(X_Button)
		with open(Save_Path+"Y_Button_Dash.cfg", 'w') as ybutton:
			ybutton.write(Y_Button)
		with open(Save_Path+"Black_Button_Dash.cfg", 'w') as blackbutton:
			blackbutton.write(Black_Button)
		with open(Save_Path+"White_Button_Dash.cfg", 'w') as whitebutton:
			whitebutton.write(White_Button)
		with open(Save_Path+"Start_Button_Dash.cfg", 'w') as startbutton:
			startbutton.write(Start_Button)
		with open(Save_Path+"Back_Button_Dash.cfg", 'w') as backbutton:
			backbutton.write(Back_Button)
		with open(Save_Path+"Custom_Dash.cfg", 'w') as backbutton:
			backbutton.write(Override_Dash)
		with open(Save_Path+"Custom_Recovery.cfg", 'w') as backbutton:
			backbutton.write(Recovery_Dash)
		xbmc.executebuiltin('Reboot')
	except: xbmcgui.Dialog().ok("ERROR","Something went wrong when saving the files.","Check the xbmc.log in Q:\\system\\","Scroll to the bottom and send me the last 10 lines.")