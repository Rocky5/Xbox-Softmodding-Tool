import os,xbmc,xbmcgui
if os.path.isdir('C:/Dashloader') and os.path.isfile('C:/Dashloader/Dashloader.log'):
	Save_Path = "C:/Dashloader/"
else:
	Save_Path = "E:/UDATA/21585554/000000000000/nkpatcher settings/dashloader/"
try:
	with open(Save_Path+"A_Button_Dash.cfg", 'r') as abutton:
		A_Button = abutton.readline().strip()
		xbmc.executebuiltin('Skin.SetString(A_Button,'+A_Button+')')
	with open(Save_Path+"B_Button_Dash.cfg", 'r') as bbutton:
		B_Button = bbutton.readline().strip()
		xbmc.executebuiltin('Skin.SetString(B_Button,'+B_Button+')')
	with open(Save_Path+"X_Button_Dash.cfg", 'r') as xbutton:
		X_Button = xbutton.readline().strip()
		xbmc.executebuiltin('Skin.SetString(X_Button,'+X_Button+')')
	with open(Save_Path+"Y_Button_Dash.cfg", 'r') as ybutton:
		Y_Button = ybutton.readline().strip()
		xbmc.executebuiltin('Skin.SetString(Y_Button,'+Y_Button+')')
	with open(Save_Path+"Black_Button_Dash.cfg", 'r') as blackbutton:
		Black_Button = blackbutton.readline().strip()
		xbmc.executebuiltin('Skin.SetString(Black_Button,'+Black_Button+')')
	with open(Save_Path+"White_Button_Dash.cfg", 'r') as whitebutton:
		White_Button = whitebutton.readline().strip()
		xbmc.executebuiltin('Skin.SetString(White_Button,'+White_Button+')')
	with open(Save_Path+"Start_Button_Dash.cfg", 'r') as startbutton:
		Start_Button = startbutton.readline().strip()
		xbmc.executebuiltin('Skin.SetString(Start_Button,'+Start_Button+')')
	with open(Save_Path+"Back_Button_Dash.cfg", 'r') as backbutton:
		Back_Button = backbutton.readline().strip()
		xbmc.executebuiltin('Skin.SetString(Back_Button,'+Back_Button+')')
	with open(Save_Path+"Custom_Dash.cfg", 'r') as override:
		Override_Dash = override.readline().strip()
		xbmc.executebuiltin('Skin.SetString(Override_Dash,'+Override_Dash+')')
	with open(Save_Path+"Custom_Recovery.cfg", 'r') as recovery:
		Recovery_Dash = recovery.readline().strip()
		xbmc.executebuiltin('Skin.SetString(Recovery_Dash,'+Recovery_Dash+')')
except: pass