FrancophilSans is made by Manfred Klein in 2005
Link to site -- http://www.moorstation.org/typoasis/designers/klein/index.htm
Link to font -- http://www.moorstation.org/typoasis/designers/klein05/text/francophilsans.htm

Terms of Use stated on his site are
"Simple Terms of Use 
  
Manfred�s fonts are free for private and charity use. 
"They are even free for commercial use but if there�s any profit, 
pls make a donation to organizations like Doctors Without Borders. 

These fonts can NOT be included in any compilation CDs, disks or products, 
either commercial or shareware unless prior permission granted."

2007.07.28 by smuto
-add 1250 Latin2: Eastern Europe (not all - only my polish glyph)
 