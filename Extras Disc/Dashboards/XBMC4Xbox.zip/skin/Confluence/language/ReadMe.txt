Only the English strings are updated in this mod.
If you want your language to be fully funcional you'll have to translate the new English strings.

Cheers,

xbs