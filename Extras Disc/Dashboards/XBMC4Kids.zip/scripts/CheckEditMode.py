######################################################################
# Script by Rocky5
# Used to enable/disable edit mode for the skin settings.
#
# Update: 05 January 2015
#
######################################################################

import os, xbmc

Enabler = xbmc.translatePath( "special://xbmc/system/keymaps/Enabled" )

if os.path.isfile(Enabler):
	xbmc.executebuiltin('Skin.SetBool(editmode)')
else:
	xbmc.executebuiltin('Skin.reset(editmode)')