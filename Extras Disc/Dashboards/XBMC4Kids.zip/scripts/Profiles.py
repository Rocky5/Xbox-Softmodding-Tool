################################################################################
# Script by Rocky5
# Used to switch between save directories.
#
# Updated: 04 June 2016
# -- Due to changes in the way I add profiles, I updated the script to just bypass the "Manage Profiles" and "DVD2Xbox" profile.
#
#
# Updated: 09 February 2016
# -- Added copying of the sources.xml this way it doesn't matter if you select use new sources when making a new profile.
#
# Updated: 21 December 2014
#
# Now copied softmod saves if they exist to new created profiles.
# Now automatically sets the skin for the new profiles.
# Now has a nice progress bar.
# Refined the script
#
################################################################################

import os, xbmcgui, xbmc, shutil, glob, fileinput, time

# Start markings for the log file.
print "============================================================"
print "============================================================"
	
	
# Sets paths, for profiles names & locations.
Username = xbmc.getInfoLabel('system.profilename')
CurProfileName = (Username + '.profile')
CurProfilePath = ('E:\\UDATA\\' + CurProfileName)
CurProfilePathAlt = ('E:\\UDATA ' + Username)
CurProfile = ('E:\\UDATA ' + Username + '\\' + CurProfileName)
GuiSettings = xbmc.translatePath( 'special://profile/guisettings.xml' )
MasProfile = xbmc.translatePath( 'special://UserData/' )
MasProfileGuiSettings = xbmc.translatePath( 'special://UserData/guisettings.xml' )
CurProfileGuiSettings = xbmc.translatePath( 'special://profile/guisettings.xml' )
MasProfileSources = xbmc.translatePath( 'special://UserData/sources.xml' )
CurProfileSources = xbmc.translatePath( 'special://profile/sources.xml' )


if Username == "Manage Profiles":
	MPLoaded = "1234" # done this so if either profile is loaded it will always be false.
else:
	MPLoaded = "false"
	
if Username == "DVD2Xbox":
	D2XLoaded = "5678" # done this so if either profile is loaded it will always be false.
else:
	D2XLoaded = "false"

if MPLoaded == D2XLoaded:
	# Removes XBMC save folder, so I can rename UDATA.
	if os.path.isdir('E:\\UDATA\\0face008\\'):
		shutil.rmtree('E:\\UDATA\\0face008\\')
		print "Removed XBMC save directory"
	else:
		print "Already removed XBMC save directory"

	# Check if UDATA exist if not make one.
	if not os.path.exists("E:\\UDATA"):
		os.mkdir("E:\\UDATA")
		print "UDATA created"
		# These will be hidden on release
		# dialog = xbmcgui.Dialog()
		# dialog.ok("Notification","UDATA folder created.")
	else:
		print "UDATA folder present"

	# Check if Backup.profile exist if not make one.
	if not os.path.exists("E:\\UDATA Backup"):
		profile = open("E:\UDATA\Backup.profile","w")
		profile.write(" ")
		profile.close()	
		print "UDATA backup created"
		# These will be hidden on release
		# dialog = xbmcgui.Dialog()
		# dialog.ok("Notification","Backup.profile created.")
	else:
		print "UDATA backup present"
		

	# Get current profile from UDATA folder.
	for TMPProfile in glob.glob(r'E:\UDATA\*.profile'):
		dirname, TMPProfile = os.path.split(TMPProfile)
		PrevProfileName, fileExtension = os.path.splitext(TMPProfile)
		PrevProfilePath = ('E:\\UDATA ' + PrevProfileName)
		PrevProfile = ('E:\\UDATA\\' + PrevProfileName + '.profile')

	# Check to see if the current user is the current save folder.
	if os.path.isfile(PrevProfile) and os.path.isfile(CurProfilePath):
		print ""
		# These will be hidden on release
		# dialog = xbmcgui.Dialog()
		# dialog.ok("Notification",Username + " saves already selected.")
		
		
	# If user created folder rename to UDATA, if not then create folder.
	elif os.path.isfile(CurProfile) and os.path.isfile(PrevProfile):
		os.rename('E:\\UDATA' , PrevProfilePath)
		os.rename(CurProfilePathAlt , 'E:\\UDATA')
		# These will be hidden on release
		# dialog = xbmcgui.Dialog()
		# dialog.ok("Notification","Changing to " + Username + " saves.")


	# Checks for the presence of the user UDATA folder & if not present creates it.
	elif not os.path.isfile(CurProfile):
		pDialog = xbmcgui.DialogProgress()
		pDialog.create('Preping save directory for '+Username)
		pDialog.update(0, 'Please wait')
		time.sleep(1)
		os.mkdir("E:\\UDATA " + Username)
		print Username+"'s"" UDATA created"
		profile = open(CurProfile,"w")
		profile.write(" ")
		profile.close()
		os.rename('E:\\UDATA' , PrevProfilePath)
		os.rename(CurProfilePathAlt , 'E:\\UDATA')
		
		# Copy over the Softmod saves if they exist.
		if os.path.exists("E:\\UDATA Backup\\4541000d"):
			pDialog.update(5, 'Copying 007 Save')
			shutil.copytree("E:\\UDATA Backup\\4541000d", "E:\\UDATA\\4541000d")
			print "Copied 007 save folder"
			time.sleep(0.2)
		else:
			print "No 007 save folder found"
			
		if os.path.exists("E:\\UDATA Backup\\4d530017"):
			pDialog.update(15, 'Copying Mechassault Save.')
			shutil.copytree("E:\\UDATA Backup\\4d530017", "E:\\UDATA\\4d530017")
			print "Copied Mechassault save folder"
			time.sleep(0.2)
		else:
			print "No Mechassault save folder found"
			
		if os.path.exists("E:\\UDATA Backup\\5553000c"):
			pDialog.update(30, 'Copying Splinter cell Save')
			shutil.copytree("E:\\UDATA Backup\\5553000c", "E:\\UDATA\\5553000c")
			print "Copied Splinter cell save folder"
			time.sleep(0.2)
		else:
			print "No Splinter cell save folder found"
			
		if os.path.exists("E:\\UDATA Backup\\21585554"):
			pDialog.update(45, 'Copying Softmod files Save')
			shutil.copytree("E:\\UDATA Backup\\21585554", "E:\\UDATA\\21585554")
			print "Copied Softmod save folder"
			time.sleep(0.2)
		else:
			print "No Softmod save folder found"
			
		if os.path.exists("E:\\UDATA Backup\\rescuedash"):
			pDialog.update(75, 'Copying Rescue Dashboard folder')
			shutil.copytree("E:\\UDATA Backup\\rescuedash", "E:\\UDATA\\rescuedash")
			print "Copied Rescue Dashboard folder"
			time.sleep(0.2)
		else:
			print "No Rescue Dashboard folder found"
			
		if os.path.exists(MasProfile):
			pDialog.update(95, 'Copying Sources.xml')
			shutil.copyfile(MasProfileSources, CurProfileSources)
			print "Copied Sources.xml"
			time.sleep(0.2)
			pDialog.update(97, 'Copying Guisettings.xml')
			shutil.copyfile(MasProfileGuiSettings, CurProfileGuiSettings)
			print "Copied Guisettings.xml"
			time.sleep(0.2)
		else:
			print "No Sources.xml file found"
			print "No Guisettings.xml file found"
			
		pDialog.update(100, 'Compleate' )
		time.sleep(1)

		# Check to see if current user is Master & if not edit current skin & log out.
		if Username == "DVD2Xbox":
			print ""
		else:
			pDialog.update(100, 'Done')
			pDialog.close()
			dialog = xbmcgui.Dialog()
			dialog.ok("That's everything setup","I will need to log you out "+Username+".","So I can complete the process.","Hope you understand.")
			
			# Change user skin.
			for line in fileinput.input(GuiSettings, inplace=True):
				print(line.replace("<skin>Manage Profiles Skin</skin>", "<skin>Profile skin</skin>"))
				xbmc.executebuiltin("System.LogOff()")
	else:
		print ""
		
	# End markings for the log file.
	print "============================================================"
	print "============================================================"
else:
	print "============================================================"
	print "Profile.py - Nothing to do."
	print "============================================================"