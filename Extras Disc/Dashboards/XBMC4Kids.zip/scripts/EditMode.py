######################################################################
# Script by Rocky5
# Used to enable/disable edit mode control file.
#
# Update: 16 February 2016
#
# Now reload the current keymap with the undocumented commend ;)
#
# Update: 15 December 2014
#
# Changed how the files are created, this fixes all issues.
# Added a dialog popup.
#
######################################################################

import os, xbmcgui, xbmc, shutil, time

Gamepad = xbmc.translatePath( "special://xbmc/system/keymaps/gamepad.xml" )
NormalMode = xbmc.translatePath( "special://xbmc/system/keymaps/UserMode.file" )
EditMode = xbmc.translatePath( "special://xbmc/system/keymaps/EditMode.file" )
Enabler = xbmc.translatePath( "special://xbmc/system/keymaps/Enabled" )

if os.path.isfile(Enabler):
	os.remove(Enabler)
	shutil.copy2(NormalMode, Gamepad)
	xbmc.executebuiltin('Skin.reset(editmode)')
	dialog = xbmcgui.Dialog()
	dialog.ok("My young padawan","","User Mode Enabled")
else:
	profile = open(Enabler,"w")
	profile.write(" ")
	profile.close()	
	shutil.copy2(EditMode, Gamepad)
	xbmc.executebuiltin('Skin.SetBool(editmode)')
	dialog = xbmcgui.Dialog()
	dialog.ok("Now, I am the Master","","Edit Mode Enabled")

xbmc.executebuiltin("Action(reloadkeymaps)")

#DashPath = xbmc.translatePath("special://xbmc/")
#from xbmc import executebuiltin
#executebuiltin("XBMC.RunXBE(%sDefault.xbe)" % DashPath)  