BiosIDs.ini [Part SystemInfo stuff!]

You can use all the Tools to create your own BIOS MD5 ini file and place it 
to the file: xbmc\System\SystemInfo\BiosIDs.ini.

If the ini does not contain the md5, it will be logged in xbmc.log file!
You cn also use the MD5 hash informations from there.

BIOS Base Detection Code comes from CrackJack! 
Big Thanks and Credits goes to CrackJack!

More Information for the Tools @ http://www.darkmoon.org!

13.02.2005 

GeminiServer
Mail: Melih@gmx.li


