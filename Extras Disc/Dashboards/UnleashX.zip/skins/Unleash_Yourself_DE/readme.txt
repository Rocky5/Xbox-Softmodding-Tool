Skin Name
===============================
Unleash Yourself Doom Ed.

Graphic base on
===============================
http://www.doomworld.com
===============================

Skin base on
===============================
Skin: C-UnleashX
Author: C-Perception
Copyright: 2004 Benjamin Lupton
Version: v1.0
cperception@hotmail.com
===============================

Tools
===============================
Adobe Photoshop CS

Date
===============================
March 16, 2005
by, faster90

I hope you enjoy my skin.
