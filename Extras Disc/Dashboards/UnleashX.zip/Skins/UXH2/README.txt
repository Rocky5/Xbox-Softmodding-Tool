Tested working with UnleashX Dash Version 0.39.0528A Build 584. May not work for some older versions of UnleashX.

INSTRUCTIONS___

	FTP "UXH2" folder to UnleashX skins folder on your Xbox(Typically "E:\Skins").
	
	If your skin changes are not saving:
		On some UnleashX installs, it writes 2 separate instances on paths to skin locations in your Config.xml. You will need to delete one of these instance or your changes will not save. You can also delete both instances. Then goto "System/Settings/System/Skins Path" and browse to your skins folder location.
		
	There are 2 intros included with this skin. To change between which one you want to show, edit the intro name in the skin.xml. The intros are similarly named "UXH2introV1" and "UXH2introV2" respectively for easy editing. All you will need to change in the skin.xml is the 1 or 2 in "<IntroMovie>UXH2introV[1 or 2 here].wmv</IntroMovie>". You can do this by FTPing the skin.xml to your PC and edit using any text editor. Or on your Xbox goto "File Explorer" navigate to the skin.xml and PRESS A to open UnleashX's Integrated Text editor(white button will bring up the virtual keyboard).
	
	
CREDITS___

	UXH2introV2 made by T3KNOSIS.
	Loading Screen by T3KNOSIS.
	All other elements by RexMundi412.
	
	
THANKS___
	
	Biggest THANKS goes to T3KNOSIS! Your help and advice are extremely appreciated. Big time thanks for making content for the skin.
	
	UXArchitect from Hectobleezy helped me in many areas. I highly recomend this program if you plan on making an UnleashX skin.
	
	Jezz author of BlackBox Skin, Tiro author of Devise v2 and DragonUX Skins. I used these skins to learn many of the elements in the skin.xml.
	
	
EXTRAS___

	If you like the UnleashX Dash Icons in the preview, you can find them here... http://www.emuxtras.net/forum/viewtopic.php?f=179&t=1089 ... Thanks to T3KNOSIS once again for those.
	