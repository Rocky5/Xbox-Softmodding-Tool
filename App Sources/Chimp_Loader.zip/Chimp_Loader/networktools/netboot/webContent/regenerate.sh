#!/bin/sh

#python genarr.py gentoox.png image/png
python genarr.py main.html text/html
python genarr.py kernel.html text/html
python genarr.py initrd.html text/html
python genarr.py append.html text/html
python genarr.py booting.html text/html

