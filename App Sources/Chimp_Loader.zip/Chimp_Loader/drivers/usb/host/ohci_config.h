/*
 * Configs for OHCI
 */

#define CONFIG_PCI
