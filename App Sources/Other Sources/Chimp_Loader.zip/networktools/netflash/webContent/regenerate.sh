#!/bin/sh

#python genarr.py gentoox.png image/png
python genarr.py main.html text/html
python genarr.py ok.html text/html
python genarr.py fail.html text/html
