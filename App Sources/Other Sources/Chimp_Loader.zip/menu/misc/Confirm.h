#ifndef __CONFIRM_H__
#define __CONFIRM_H__

int Confirm(char *message, char *noText, char *yesText, int defaultItem);
#endif
